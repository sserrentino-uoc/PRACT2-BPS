"""PRACT2 package."""
